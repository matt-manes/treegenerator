# Changelog

## 1.1.0 (2023-05-10)

#### Others

* remove dependency versions